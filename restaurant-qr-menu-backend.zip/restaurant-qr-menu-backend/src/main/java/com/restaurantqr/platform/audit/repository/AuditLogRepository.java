package com.restaurantqr.platform.audit.repository;

import com.restaurantqr.platform.audit.entity.AuditLog;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AuditLogRepository extends JpaRepository<AuditLog, Long> {
    Page<AuditLog> findByRestaurantIdOrderByTimestampDesc(Long restaurantId, Pageable pageable);
    List<AuditLog> findTop20ByRestaurantIdOrderByTimestampDesc(Long restaurantId);
}
